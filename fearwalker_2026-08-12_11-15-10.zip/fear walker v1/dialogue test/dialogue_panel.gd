extends Control

const SCROLL_SPEED : float = 20.0

@export var text_to_display = "test dialogue \n test dialogue line 2 \n test dialogue line 3"
var last_text = null

@onready var label = $Label
@export var time_elapsed = 0.0

func reset():
	label.text = text_to_display
	label.visible_characters = 0
	time_elapsed = 0
	last_text = text_to_display

func _ready() -> void:
	reset()

func _process(delta: float) -> void:
	time_elapsed += SCROLL_SPEED * delta
	label.visible_characters = int(time_elapsed)
	
	if last_text != text_to_display:
		reset()
