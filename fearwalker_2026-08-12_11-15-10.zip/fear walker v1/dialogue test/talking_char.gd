extends Area2D

@onready var ind = $TalkInd
@onready var clayer = $CanvasLayer
var player_in_bounds : CharacterBody2D = null
var talking_to = false

@export var dialogue : Array[String] = [
	"line1",
	"line2",
	"line3"
]
var cur_dialogue_line = 0

var dbox = preload("res://dialogue test/dialogue_Box.tscn").instantiate()

func _on_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if body.name == "Player":
		player_in_bounds = body
		ind.visible = true

func _on_body_shape_exited(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if body.name == "Player":
		player_in_bounds = null
		ind.visible = false

func _input(event: InputEvent) -> void:
	if not player_in_bounds: return
	if event.is_action_pressed("E"):
		if talking_to == false:
			#player_in_bounds.speed = 0.0 
			talking_to = true
			cur_dialogue_line = 0
			clayer.add_child(dbox)
		
		if talking_to == true:
			if not dialogue.get(cur_dialogue_line):
				clayer.remove_child(dbox)
				cur_dialogue_line = 0
				talking_to = false
				player_in_bounds.speed = 300.0
				return
			var line = dialogue[cur_dialogue_line]
			dbox.text_to_display = line
			cur_dialogue_line += 1
			

func _physics_process(delta: float) -> void:
	if player_in_bounds and talking_to == true:
		player_in_bounds.speed = 0.0 
