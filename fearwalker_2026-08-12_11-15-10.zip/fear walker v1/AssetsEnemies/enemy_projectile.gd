extends Area2D

@export var velocity = Vector2.ZERO
@export var shooter : Node2D

var timeout = 800

func _on_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if body == shooter: return
	
	if body.name == "Player":
		body.queue_free() #tba, add death state
	
	queue_free()

func _physics_process(delta: float) -> void:
	timeout -= 1
	if timeout <= 0:
		queue_free()
		return
	
	position += velocity*delta
