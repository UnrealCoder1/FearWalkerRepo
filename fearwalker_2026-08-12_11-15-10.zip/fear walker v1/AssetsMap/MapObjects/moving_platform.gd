extends Node2D

@export var speed = 1.0
@export var from = 0.0

@onready var animator : AnimationPlayer = $AnimationPlayer

func _ready():
	#animator.speed_scale = speed
	animator.play("move_loop",0.0,speed,from)
