
class_name CollectibleBehaviour
extends Node

@onready var collect_collision : Area2D = $CollectibleCollision;
@export var collectible_tag: StringName = "Collectible";
@export_range(1.0, 100.0) var amount_min : int = 2;
@export_range(1.0, 100.0) var amount_max : int = 4;

signal ExecuteCollisionEffect(CollectibleTag: StringName, RecievedAmount : int);

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		print("Player collected the item!");
		ExecuteCollisionEffect.emit(collectible_tag, randi_range(amount_min, amount_max));
	
		queue_free();
