
class_name BasicProjectile
extends StaticBody2D

@export_range(20.0, 300.0) var damage_to_deal : float = 100.0;
@export var speed : float = 100.0;

var velocity : Vector2 = Vector2(1.0, 0.0);

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	await get_tree().create_timer(0.2).timeout;
	$Area2D.connect("area_entered", _on_body_entered);
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	velocity = Vector2.RIGHT.rotated(global_rotation) * speed;
	global_position += velocity * delta;
	pass

func _on_body_entered(body : Node2D) -> void:
	
	var health_component : HealthComponent = body.get_node_or_null("ObjectHealthComponent");
	if(health_component != null):
		health_component.take_damage(damage_to_deal);
	
	self.queue_free();
	
	pass
