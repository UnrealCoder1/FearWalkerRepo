
class_name GameUtilities
extends RefCounted

static func EliminationLogic(body : Node2D) -> void:
	body.get_tree().paused = true;
	await body.get_tree().create_timer(0.5).timeout;
	body.get_tree().reload_current_scene();
	pass

static func SphereTrace(body : Node2D, target_position : Vector2, space_state: PhysicsDirectSpaceState2D) -> Array[Dictionary]:
	
	var shape := CircleShape2D.new()
	shape.radius = 20.0
	
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.transform = Transform2D(0.0, target_position)
	query.collision_mask = 1
	
	return space_state.intersect_shape(query);
	pass;

#static func LineTrace(body : Node2D, start_position : Vector2, end_position : Vector2, space_state: PhysicsDirectSpaceState2D) -> void:
	#pass
