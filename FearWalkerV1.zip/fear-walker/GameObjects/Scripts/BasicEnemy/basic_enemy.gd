
class_name BasicEnemy
extends StaticBody2D

@export var damage := 100.0;
@export var steps : int  = 100;

var bReached : bool = false;

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	$AnimatedSprite2D.flip_h = true;
	$Area2D.body_entered.connect(_on_body_entered);
	
	
	pass # Replace with function body.
	

var space_state : PhysicsDirectSpaceState2D;

func move_right(steps : int) -> void:
	$AnimatedSprite2D.flip_h = true;
	for i in range(steps):
		global_position.x += 0.01;
		await get_tree().create_timer(0.01).timeout;
	bReached = true;

func move_left(steps : int) -> void:
	$AnimatedSprite2D.flip_h = false;
	for i in range(steps):
		global_position.x -= 0.01;
		await get_tree().create_timer(0.01).timeout;
	bReached = false;

func Destroy(body : Node2D) -> void:
	if not body is Player : return;
	
	(body as Player).player_health -= damage;
	$AnimatedSprite2D.play("ExplosionAnim");
	self.global_scale = Vector2(3, 3);
	
	await $AnimatedSprite2D.animation_finished;
	print((body as Player).player_health)
	queue_free();

func _on_body_entered(body : Node2D) -> void:
	Destroy(body);


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	if(self == null): return;
	
	if(bReached):
		await move_left(steps);
	else:
		await move_right(steps);
	
	pass
