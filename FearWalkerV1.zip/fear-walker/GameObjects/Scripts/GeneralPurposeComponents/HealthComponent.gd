
class_name HealthComponent
extends Node

@export_range(20.0, 300.0) var health : float = 100.0;

func take_damage(amount : float) -> void:
	health = clamp(health - amount, 20.0, 300.0);

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
