
class_name KillVolumeBehaviour
extends Node

@onready var volume : Area2D = get_parent();

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	volume.body_entered.connect(_on_body_entered);
	pass # Replace with function body.

func _on_body_entered(body : Node2D) -> void:
	
	if(body is Player):
		GameUtilities.EliminationLogic(body);

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
