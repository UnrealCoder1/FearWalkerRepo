
class_name CollectibleBehaviour
extends Node

@onready var collect_collision : Area2D = get_parent();
@export var collectible_tag: StringName = "Collectible";
@export_range(1.0, 100.0) var amount_min : int = 2;
@export_range(1.0, 100.0) var amount_max : int = 4;

signal ExecuteCollisionEffect(CollectibleTag: StringName, RecievedAmount : int);

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	collect_collision.body_entered.connect(_on_body_entered);
	pass

func _on_body_entered(body: Node2D) -> void:
	print("ENTERED: ", body.name)
	print("Body position: ", body.global_position)
	print("Area position: ", collect_collision.global_position)
	
	if body is Player:
		print("Player collected the item!");
		ExecuteCollisionEffect.emit(collectible_tag, randi_range(amount_min, amount_max));
	
		collect_collision.queue_free();
