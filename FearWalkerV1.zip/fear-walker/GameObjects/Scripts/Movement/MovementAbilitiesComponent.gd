
class_name MovementAbilitiesComponent
extends Node

enum EMovementStates{
	Dashing,
	Running,
	SlowFalling
}

var MovementTags: Array[EMovementStates] = [];
var Stamina : float = 100.0;

var NumOfJumps := 0;

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func Dash(character: Player, speed: float, wait: float) -> void:
	
	if(Stamina < character.DASH_COST): return;
	
	var dir : Variant = sign(character.velocity.x);

	if dir == 0:
		if character.bLookingRight == true:
			dir = 1;
		else: dir = -1;
	
	
	MovementTags.append(EMovementStates.Dashing);
	character.velocity.x += dir * speed;
	print(character.velocity);
	
	Stamina = clamp(Stamina - character.DASH_COST, 0.0, 100.0);
	
	await get_tree().create_timer(wait).timeout;
	MovementTags.erase(EMovementStates.Dashing);

func Run(character: Player) -> void:
	
	if(character.velocity.normalized() == Vector2.ZERO): return;
	
	if(Stamina < character.RUN_COST): 
		StopRun(character);
		return;
	
	character.speed = character.RUN_SPEED;
	MovementTags.append(EMovementStates.Running);

func StopRun(character: Player) -> void:
	character.speed = character.WALK_SPEED;
	MovementTags.erase(EMovementStates.Running);

func EnhancedJump(character: Player) -> void:
	
	if NumOfJumps > 0:
		if Stamina < character.ENHANCED_JUMP_COST: return;
		Stamina = clamp(Stamina - character.ENHANCED_JUMP_COST, 0.0, 100.0);
	
	character.velocity.y = character.JUMP_VELOCITY;
	NumOfJumps += 1;

func CalculateStaminaCosts(character: Player) -> void:
	if(MovementTags.has(EMovementStates.Running)):
		Stamina = clamp(Stamina - character.RUN_COST, 0.0, 100.0);
	
	if(MovementTags.has(EMovementStates.Running)):
		Stamina = clamp(Stamina - character.SLOW_FALL_COST, 0.0, 100.0);

func RegenStamina() -> void:
	var start_stamina: float = Stamina;
	
	await get_tree().create_timer(0.1).timeout;
	
	if(Stamina == start_stamina and Stamina < 100.0):
		Stamina = clamp(Stamina + 2, 0.0, 100.0);

func SlowFall(character: Player) -> void:
	if(character.is_on_floor()): return;
	character.gravity_scale = 0.3;
	MovementTags.append(EMovementStates.SlowFalling);

func StopSlowFall(character: Player) -> void:
	character.gravity_scale = 1.0;
	MovementTags.erase(EMovementStates.SlowFalling);
