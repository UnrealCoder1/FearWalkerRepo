extends Area2D

@onready var collect_behaviour := $CollectibleBehaviour;
var player : Player;

func __on_collect(CollectibleTag: StringName, RecievedAmount : int) -> void:
	player.SpidersCollected += RecievedAmount;


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	player = get_tree().get_first_node_in_group("Player");
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
