extends Node2D

@onready var collect_behaviour : CollectibleBehaviour = $CollectibleBehaviour;

var character : Player;

func __on_collect(CollectibleTag: StringName, RecievedAmount : int) -> void:
	character.FiresCollected += RecievedAmount;
	print("Collected");
	pass

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	character = get_tree().get_first_node_in_group("Player")
	collect_behaviour.ExecuteCollisionEffect.connect(__on_collect);
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
