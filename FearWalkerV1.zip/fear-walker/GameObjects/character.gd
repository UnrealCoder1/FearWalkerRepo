class_name Player
extends CharacterBody2D

const WALK_SPEED := 300.0;
const RUN_SPEED := 600.0;
const RUN_COST := 0.5;
const DASH_COST := 20.0;
const ENHANCED_JUMP_COST := 10.0;
const SLOW_FALL_COST := 1.0;

const MAX_HEALTH := 100.0;
const MIN_HEALTH := 100.0;

var FiresCollected : int = 0;
var SpidersCollected : int = 0;

var speed = 300.0
var gravity_scale : float = 1.0;
var player_health : float = 100.0;
var bLookingRight := true;
var bExecutedLanding := true;

const DEFAULT_SPAWNER_OFFSET_X_RIGHT = 35.0;
const DEFAULT_SPAWNER_OFFSET_X_LEFT = 35.0;

const JUMP_VELOCITY = -400.0

@onready var movement_abilities : MovementAbilitiesComponent = $MovementAbilities
@onready var animated_sprite : AnimatedSprite2D = $PlayerAnimatedSprite
@onready var default_projectile_spawner : Marker2D = $DefaultSpawner

var bCanSpawn : bool = true;

func SpawnProjectile() -> void:
	
	if(bCanSpawn == false): return
	bCanSpawn = true
	
	var projectile_scene = preload("res://GameObjects/Scripts/Projectile/Projectile.tscn");
	var projectile : BasicProjectile = projectile_scene.instantiate();
	
	projectile.global_position = default_projectile_spawner.global_position;
	projectile.global_rotation = default_projectile_spawner.global_rotation + randf_range(-0.1, 0.1);
	get_tree().current_scene.add_child(projectile);
	
	await get_tree().create_timer(0.05).timeout;
	bCanSpawn = true;
	pass

func OnLanded() -> void:
	if(bExecutedLanding == true): return;
	bExecutedLanding = true;
	
	animated_sprite.play("Falling");
	animated_sprite.play("Idle")
	pass

func ExecuteAnimationBasedLogic() -> void:
	
	if(movement_abilities.HasMovementTag(MovementAbilitiesComponent.EMovementStates.SlowFalling)):
		animated_sprite.play("InAirIdle");
	
	pass

func ExecuteDirectionBasedLogic(direction: float) -> void:
	
	if direction == 0:
		if(!movement_abilities.HasMovementTag(MovementAbilitiesComponent.EMovementStates.Idle)):
			movement_abilities.StopRun(self);
			movement_abilities.MovementTags.append(MovementAbilitiesComponent.EMovementStates.Idle);
			animated_sprite.play("Idle");
	else:
		movement_abilities.MovementTags.erase(MovementAbilitiesComponent.EMovementStates.Idle);
	
	if direction < 0:
		animated_sprite.flip_h = true;
		default_projectile_spawner.rotation_degrees = 180.0;
		default_projectile_spawner.position.x = -DEFAULT_SPAWNER_OFFSET_X_LEFT;
		bLookingRight = false;
	elif direction > 0:
		animated_sprite.flip_h = false;
		default_projectile_spawner.rotation_degrees = 0.0;
		default_projectile_spawner.position.x = DEFAULT_SPAWNER_OFFSET_X_RIGHT;
		bLookingRight = true;
	
func __try_execute_basic_walk(direction: float) -> void:
	
	if direction and movement_abilities.MovementTags.has(MovementAbilitiesComponent.EMovementStates.Dashing) == false:
		velocity.x = direction * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
	
	if(!movement_abilities.MovementTags.has(MovementAbilitiesComponent.EMovementStates.Walking)): 
		movement_abilities.MovementTags.append(MovementAbilitiesComponent.EMovementStates.Walking);
	
	if(!is_on_floor()): return
	
	if(movement_abilities.HasMovementTag(MovementAbilitiesComponent.EMovementStates.Running)):
		animated_sprite.play("Running");
	elif !movement_abilities.HasMovementTag(MovementAbilitiesComponent.EMovementStates.Idle):
		animated_sprite.play("walking");
	
	pass

func __try_execute_jump() -> void:
	if Input.is_action_just_pressed("Space") and movement_abilities.NumOfJumps < 2:
		movement_abilities.EnhancedJump(self);
		animated_sprite.play("Jumping");
	pass

func __try_execute_run() -> void:
	if Input.is_action_just_pressed("Shift"):
		movement_abilities.Run(self);
	
	if Input.is_action_just_released("Shift"):
		movement_abilities.StopRun(self);
	pass

func __try_execute_dash() -> void:
	if Input.is_action_just_pressed("ALT"):
		movement_abilities.Dash(self, 2700.0, 0.3)
		animated_sprite.play("OnGroundDashing");
		
		await get_tree().create_timer(0.2).timeout;
		if(!is_on_floor()): animated_sprite.play("InAirIdle");
	pass

func __try_execute_slow_fall() -> void:
	if Input.is_action_just_pressed("Ctrl"):
		movement_abilities.SlowFall(self);
	
	if Input.is_action_just_released("Ctrl"):
		movement_abilities.StopSlowFall(self)
	pass

func __try_spawn_projectile() -> void:
	if(Input.is_action_just_pressed("LeftMouseButton")):
		SpawnProjectile();

func _ready() -> void:
	get_tree().paused = false;
	add_to_group("Player");
	pass

func __try_exit_walk_state() -> void:
	if(movement_abilities.HasMovementTags([
		MovementAbilitiesComponent.EMovementStates.Dashing,
		MovementAbilitiesComponent.EMovementStates.Running,
		MovementAbilitiesComponent.EMovementStates.SlowFalling,
		MovementAbilitiesComponent.EMovementStates.Idle
	], false)):
		if(movement_abilities.HasMovementTag(MovementAbilitiesComponent.EMovementStates.Walking)): 
			movement_abilities.MovementTags.erase(MovementAbilitiesComponent.EMovementStates.Walking);
	pass

func _physics_process(delta: float) -> void:
	# Add the gravity.
	
	if not is_on_floor():
		velocity += get_gravity() * gravity_scale * delta
		bExecutedLanding = false;
	else:
		movement_abilities.NumOfJumps = 0;
		movement_abilities.StopSlowFall(self);
		OnLanded();
	
	ExecuteAnimationBasedLogic();
	
	# Handle jump.
	__try_execute_jump();
	
	__try_execute_run()
	
	var direction : float = Input.get_axis("A", "D")
	
	
	ExecuteDirectionBasedLogic(direction);
	
	#Note: Dash, walk and fall execution require direction logic executed for the sake of simplicity
	__try_execute_basic_walk(direction);
	
	__try_execute_dash();
	
	__try_execute_slow_fall();
	
	__try_spawn_projectile();
	
	movement_abilities.CalculateStaminaCosts(self);
	movement_abilities.RegenStamina();
	
	move_and_slide()
