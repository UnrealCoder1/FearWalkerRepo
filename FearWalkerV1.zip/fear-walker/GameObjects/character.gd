class_name Player
extends CharacterBody2D

const WALK_SPEED := 300.0;
const RUN_SPEED := 600.0;
const RUN_COST := 0.5;
const DASH_COST := 20.0;
const ENHANCED_JUMP_COST := 10.0;
const SLOW_FALL_COST := 1.0;

const MAX_HEALTH := 100.0;
const MIN_HEALTH := 100.0;

var speed = 300.0
var gravity_scale : float = 1.0;
var player_health : float = 100.0;
var bLookingRight := true;

const JUMP_VELOCITY = -400.0

@onready var movement_abilities : MovementAbilitiesComponent = $MovementAbilities
@onready var animated_sprite : AnimatedSprite2D = $PlayerAnimatedSprite

func ExecuteDirectionBasedLogic(direction: float) -> void:
	if direction != 0: animated_sprite.play("default");
	else: animated_sprite.stop();
	
	if direction < 0:
		animated_sprite.flip_h = true;
		bLookingRight = false;
	elif direction > 0:
		animated_sprite.flip_h = false;
		bLookingRight = true;

func __try_execute_basic_walk(direction: float) -> void:
	
	if direction and movement_abilities.MovementTags.has(MovementAbilitiesComponent.EMovementStates.Dashing) == false:
		velocity.x = direction * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
	
	pass

func __try_execute_jump() -> void:
	if Input.is_action_just_pressed("Space") and movement_abilities.NumOfJumps < 2:
		movement_abilities.EnhancedJump(self);
	pass

func __try_execute_run() -> void:
	if Input.is_action_just_pressed("Shift"):
		movement_abilities.Run(self);
	
	if Input.is_action_just_released("Shift"):
		movement_abilities.StopRun(self);
	pass

func __try_execute_dash() -> void:
	if Input.is_action_just_pressed("ALT"):
		movement_abilities.Dash(self, 2700.0, 0.3)
	pass

func __try_execute_slow_fall() -> void:
	if Input.is_action_just_pressed("Ctrl"):
		movement_abilities.SlowFall(self);
	
	if Input.is_action_just_released("Ctrl"):
		movement_abilities.StopSlowFall(self)
	pass

func _ready() -> void:
	self.add_to_group("Player", true);
	pass

func _physics_process(delta: float) -> void:
	# Add the gravity.
	
	if not is_on_floor():
		velocity += get_gravity() * gravity_scale * delta
	else:
		movement_abilities.NumOfJumps = 0;
		movement_abilities.StopSlowFall(self);
	
	# Handle jump.
	__try_execute_jump();
	
	__try_execute_run()
	
	var direction : float = Input.get_axis("A", "D")
	
	ExecuteDirectionBasedLogic(direction);
	
	#Note: Dash, walk and fall execution require direction logic executed for the sake of simplicity
	__try_execute_basic_walk(direction);
	
	__try_execute_dash();
	
	__try_execute_slow_fall();
	
	movement_abilities.CalculateStaminaCosts(self);
	movement_abilities.RegenStamina();
	
	print("Stamina: ",movement_abilities.Stamina )
	
	move_and_slide()
