extends CharacterBody2D

var pre_projectile = preload("res://AssetsEnemies/enemy_projectile.tscn")

@onready var wallray = $RayCast2D
@onready var og_pos = position

const SPEED = 200

var target : CharacterBody2D
var detect_dist = 400
var dash_time = 100
var des_velocity = Vector2.ZERO

var shot_fired = false
var dash = false

func find_target():
	var t = get_parent().find_child("Player")
	if t:
		target = t

func _ready() -> void:
	find_target()
	
func _physics_process(delta: float) -> void:
	if not target:
		find_target()
		return
	var dist_From_target = target.position.distance_to(position)
	if dist_From_target < detect_dist:
		detect_dist = 600
		#print(dash_time)
		if dash_time > 20 and dist_From_target > 128: ##Move toward
			des_velocity = ((target.position-Vector2(0,32))-position).normalized() * SPEED
		else:
			des_velocity = Vector2.ZERO
		
		dash_time -= 1
		
		if dash_time < 0:
			if shot_fired == false and dash == false: ##Decide between shooting and dashing
				if dist_From_target > 400:
					dash = true
				else: ##Shooting
					shot_fired = true
					
					var new_projectile = pre_projectile.instantiate()
					get_parent().add_child(new_projectile)
					new_projectile.shooter = self
					new_projectile.velocity = ((target.position-Vector2(0,32))-position).normalized() * 250
					new_projectile.position = position
					
			if shot_fired == false and dash == true: ##Dash
				des_velocity = ((target.position-Vector2(0,32))-position).normalized() * SPEED * 3
		
		if dash_time <= -40: ##Reset
			shot_fired = false
			dash = false
			dash_time = 300
	else:
		des_velocity = (og_pos-position).normalized() * SPEED/1.5
		dash_time = 300
		detect_dist = 300
		
	velocity = velocity.lerp(des_velocity,5*delta)
	
	if position.distance_to(og_pos) > 5:
		if sign(velocity.x) == 1:
			$AnimatedSprite2D.flip_h = true
		else:
			$AnimatedSprite2D.flip_h = false
	
	#wallray.target_position = velocity
	#wallray.force_raycast_update()
	#var rayhit = wallray.get_collider()
	#if rayhit != target:
		#var norm = wallray.get_collision_normal()
		#print(norm)
		#
		#velocity -= norm*SPEED/2
		##print(rayhit)
	#
	move_and_slide()
